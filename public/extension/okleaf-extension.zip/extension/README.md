OkLeaf Browser Extension (Chrome/Firefox)

Local install (developer mode):
1) Open chrome://extensions (or about:addons in Firefox).
2) Enable Developer Mode.
3) Load unpacked and select the "extension" folder.
4) Open the extension Options page and set your API key.

Notes:
- Uses the API key to call POST /api/links.
- Copies the short URL to your clipboard.
